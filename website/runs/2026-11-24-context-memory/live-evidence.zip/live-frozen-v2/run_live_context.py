"""Run the native app on pixel fixtures; no OCR/translation transcript injection."""
from pathlib import Path
import argparse,json,subprocess,time,hashlib,shutil
p=argparse.ArgumentParser();p.add_argument('--provider',choices=['openai','custom'],required=True);p.add_argument('--scene',choices=['bar','garden'],required=True);p.add_argument('--mode',choices=['off','recent','selected'],required=True);p.add_argument('--tag',default='');a=p.parse_args()
root=Path(__file__).resolve().parents[1];exp=root/'outputs/context-memory-2026-11-24';app=root/'outputs/FrameLab-PC-2026-11-23/app';out=exp/'live-runs'/f'{a.provider}-{a.scene}-{a.mode}{a.tag}';out.mkdir(parents=True,exist_ok=False)
config=json.loads((exp/'server-config.json').read_text(encoding='utf-8'))
settings=(exp/'live-scenes/settings-before-tests.txt').read_text(encoding='utf-8').strip().split(' ',10)
settings[0]='14';settings[5]='3.5';settings[6]='0.95'
base=' '.join(settings)
extra=[str(int(a.mode!='off')),str(int(a.mode=='selected')),json.dumps(config['url']),json.dumps(config['protocol']),json.dumps(config['model']),json.dumps(json.dumps(config['parameters'])),json.dumps(''),'30','256','1','0']
(app/'subtitle-settings.txt').write_text(base+' '+' '.join(extra)+'\n',encoding='utf-8')
cmd=[str(app/'FrameLab.exe'),'--video',str(exp/'live-scenes'/f'{a.scene}.mp4'),'--subtitles','--source-language','en','--target-language','cs','--translation-provider',a.provider,'--conversation-memory',a.mode,'--context-trace',str(out/'worker.jsonl'),'--subtitle-trace',str(out/'render.jsonl'),'--api-model','gpt-6-luna','--api-effort','none','--subtitle-filter','2','--fg','--nr','--nr-height','540','--nr-passes','1','--seconds','85','--debug-seconds','85','--debug-text']
meta=dict(started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),command=cmd,provider=a.provider,scene=a.scene,mode=a.mode,app_sha256=hashlib.sha256((app/'FrameLab.exe').read_bytes()).hexdigest(),worker_sha256=hashlib.sha256((app/'translation/translate_worker.py').read_bytes()).hexdigest(),memory_sha256=hashlib.sha256((app/'translation/subtitle_evidence_memory.py').read_bytes()).hexdigest(),scope='Native app -> Media Foundation decoded source pixels -> RapidOCR -> selected provider -> own memory -> rendered subtitle; FG and NR requested. Actual activation/performance must be confirmed in logs/UI.')
(out/'metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
old_debug=set((app/'logs').glob('debug-*'));usage=app/'logs/openai-usage.jsonl';usage_offset=usage.stat().st_size if usage.exists() else 0
process=subprocess.Popen(cmd,cwd=app);print('START',out.name,'PID',process.pid,flush=True)
while process.poll() is None:
 time.sleep(5)
 worker=out/'worker.jsonl';n=len(worker.read_text(encoding='utf-8').splitlines()) if worker.exists() else 0
 (out/'progress.json').write_text(json.dumps(dict(pid=process.pid,completed=False,worker_records=n)),encoding='utf-8')
meta.update(completed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),exit_code=process.returncode)
for directory in set((app/'logs').glob('debug-*'))-old_debug:
 if directory.is_dir():
  for name in ['events.jsonl','metrics.csv','frames.csv','session.json','summary.json']:
   if (directory/name).exists():shutil.copy2(directory/name,out/name)
if a.provider=='openai' and usage.exists():
 with usage.open('rb') as f:f.seek(usage_offset);(out/'api-usage.jsonl').write_bytes(f.read())
(out/'metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8');(out/'progress.json').write_text(json.dumps(dict(completed=True,exit_code=process.returncode)),encoding='utf-8');print('DONE',out.name,process.returncode,flush=True)
