"""Burn authored dialogue into gameplay pixels for actual FrameLab OCR tests."""
from pathlib import Path
import json,subprocess,hashlib
root=Path(__file__).resolve().parents[1];out=root/'outputs/context-memory-2026-11-24/live-scenes';out.mkdir(exist_ok=True)
ffmpeg=root/'outputs/FrameLab-preview18/release/FrameLab-0.2.0-preview.18/deps/python/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe'
source=root/'outputs/FrameLab-PC-2026-11-23/app/samples/gta.mp4'
filler=['Did you hear that noise?','It is probably nothing.','I could use a coffee.','We should keep moving.','The weather is getting worse.','Wait, I dropped my keys.','Do you remember that song?','Not really.','My phone is almost dead.','There is a light upstairs.','AB 123 CD','CLOSE','Did you lock the door?','Yes, twice.','That was a long day.','I know what you mean.','We should hurry.','Give me a moment.','Do you have any water?','There is a bottle in my bag.']
def stamp(t):return f'{int(t//3600)}:{int(t//60)%60:02}:{int(t)%60:02}.{int(t%1*100):02}'
for scene,opening,correction in [
 ('garden',['We are clearing weeds from the vegetable garden.','The gardener left a hoe beside the kitchen door.'],['We are now talking about the woman at the bar.','The bartender calls her a hoe because she flirts with everyone.']),
 ('bar',['We are at a bar, talking about a woman who keeps flirting.','The bartender calls that woman a hoe.'],['We are now clearing weeds in the vegetable garden.','The gardener left a hoe beside the kitchen door.'])]:
 rows=[];t=6.
 for phase,text,duration in [('opening',s,5.) for s in opening]+[('target-immediate','Get that hoe out of here.',5.)]+[('filler',s,2.) for s in filler]+[('target-delayed','Get that hoe out of here.',6.)]+[('correction',s,5.) for s in correction]+[('target-corrected','Get that hoe out of here.',6.)]:
  rows.append(dict(id=f'{scene}-{len(rows)+1}',phase=phase,text=text,start=t,end=t+duration));t+=duration
 ass='''[Script Info]
ScriptType: v4.00+
PlayResX: 1280
PlayResY: 720
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Arial,30,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,2,0,2,120,120,100,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
 for r in rows:ass+=f"Dialogue: 0,{stamp(r['start'])},{stamp(r['end'])},Default,,0,0,0,,{r['text']}\n"
 (out/f'{scene}.ass').write_text(ass,encoding='utf-8')
 cmd=[str(ffmpeg),'-hide_banner','-loglevel','error','-y','-stream_loop','-1','-i',str(source),'-t',str(t+3),'-vf',f'scale=1280:720,drawbox=x=0:y=520:w=1280:h=200:color=black:t=fill,ass={scene}.ass','-an','-r','30','-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p',f'{scene}.mp4']
 subprocess.run(cmd,cwd=out,check=True)
 (out/f'{scene}.json').write_text(json.dumps(dict(scope='Authored conversation burned into gameplay pixels. Actual app must OCR it; no transcript injection. Mixed dialogue/HUD/plate; topic reversal; 2-second filler tests drops. Background is a repeated existing GTA sample, not the original dialogue scene.',rows=rows,duration_s=t+3,sha256=hashlib.sha256((out/f'{scene}.mp4').read_bytes()).hexdigest()),ensure_ascii=False,indent=2),encoding='utf-8')
 print(scene,len(rows),t+3,flush=True)
